"""Integration smoke test against a fresh local database. Run: python tests/smoke.py"""
import base64
import http.cookiejar
import json
import os
import re
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.parse
import urllib.request
from http.server import HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from local import Local
from api import slip

class Client:
    def __init__(self, origin):
        self.origin = origin
        self.http = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def call(self, action, body=None, **params):
        url = self.origin + "/api/slip?" + urllib.parse.urlencode(dict(action=action, **params))
        req = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None,
                                     headers={"Origin":self.origin, "Content-Type":"application/json"})
        try:
            response = self.http.open(req)
        except urllib.error.HTTPError as err:
            response = err
        with response:
            return response.status, json.load(response)

    def auth(self, action, number, password):
        _, ch = self.call("challenge", {})
        ans = sum(map(int, re.findall(r"\d+", ch["question"])))
        return self.call(action, dict(challenge=ch["challenge"],answer=ans,phone=number,
                                      name="Student",password=password))

class Flow(unittest.TestCase):
    def test_group_flow(self):
        with tempfile.TemporaryDirectory() as tmp:
            for var in ["DATABASE_URL","POSTGRES_URL","VERCEL"]:
                os.environ.pop(var,None)
            os.environ["SPLIT_LOCAL_DB"] = str(Path(tmp)/"test.db")
            slip.ready=False
            server=HTTPServer(("127.0.0.1",0),Local)
            worker=threading.Thread(target=server.serve_forever,daemon=True)
            worker.start()
            self.addCleanup(server.server_close)
            self.addCleanup(server.shutdown)
            origin="http://127.0.0.1:"+str(server.server_port)
            a,b,outsider=(Client(origin) for _ in range(3))
            self.assertEqual(a.call("state")[0],401)
            self.assertEqual(a.auth("signup","9000000001","student123")[0],200)
            self.assertEqual(a.auth("signup","9000000001","student123")[0],409)
            self.assertEqual(b.auth("signup","9000000002","student234")[0],200)
            self.assertEqual(outsider.auth("signup","9000000003","student345")[0],200)
            _,s=a.call("state"); gid=s["groups"][0]["id"]
            def group(c):
                return c.call("group",group=gid)
            def change(c,action,**fields):
                rev=group(c)[1]["revision"]
                return c.call(action,dict(group=gid,revision=rev,**fields))
            self.assertEqual(group(b)[0],404)
            self.assertEqual(change(a,"member",name="Roommate",phone="9000000002",upi="")[0],200)
            _,invite=change(a,"invite",index=1)
            self.assertEqual(outsider.call("join",invite)[0],400)
            self.assertEqual(b.call("join",invite)[0],200)
            self.assertEqual(b.call("join",invite)[0],400)
            self.assertEqual(change(b,"member",index=0,name="Other",phone="9000000001",upi="abc@bank")[0],403)
            expense=dict(title="Hostel power",amount=50000,cat="Electricity",payer=0,shares={"0":25000,"1":25000},date="2026-11-20T10:00:00Z")
            self.assertEqual(change(a,"expense",**expense)[0],400)
            receipt={"name":"test.pdf","data":"data:application/pdf;base64,"+base64.b64encode(b"%PDF-1.4 test").decode()}
            self.assertEqual(change(a,"expense",bill=receipt,**expense)[0],200)
            e=group(b)[1]["expenses"][0]
            self.assertEqual(e["amount"],50000)
            self.assertEqual(b.call("bill",group=gid,id=e["bill"]["id"])[1]["data"],receipt["data"])
            self.assertEqual(outsider.call("bill",group=gid,id=e["bill"]["id"])[0],404)
            self.assertEqual(change(b,"comment",index=0,text="Checked the bill.")[0],200)
            self.assertEqual(a.call("comment",dict(group=gid,revision=0,index=0,text="stale"))[0],409)
            self.assertEqual(change(b,"settle",**{"from":1,"to":0,"amount":25000})[0],200)
            self.assertEqual(change(b,"settle",**{"from":1,"to":0,"amount":25000})[0],409)
            self.assertEqual(b.call("logout",{})[0],200)
            self.assertEqual(b.call("state")[0],401)
            self.assertEqual(b.auth("login","9000000002","badpassword")[0],401)
            self.assertEqual(b.auth("login","9000000002","student234")[0],200)
            self.assertEqual(group(b)[1]["expenses"][0]["comments"][0]["text"],"Checked the bill.")
            for path in ["/","/login.htm","/account.js","/dashboard.htm"]:
                with a.http.open(origin+path) as r:
                    self.assertEqual(r.status,200)
if __name__=="__main__":
    unittest.main()
